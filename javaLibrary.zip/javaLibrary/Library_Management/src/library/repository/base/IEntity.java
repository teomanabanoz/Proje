package library.repository.base;

public interface IEntity {
    int getId();
    void setId(int id);
}
